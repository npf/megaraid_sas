#!/bin/bash
###############################################################################
# This script:
# - fetches the megacli_sas driver (version 7) for H740p from Broadcom's
#   website ;
# - extracts sources and prepares/fixes dkms (bogus version).
#
###############################################################################

set -e
URL=https://docs.broadcom.com/docs-and-downloads/raid-controllers/raid-controllers-common-files/MR_LINUX_DRIVER_7.5-07.705.02.00-1.tgz
FILE=${URL##*/}
DIR=${FILE%.tgz}
wget -nc $URL
cat <<EOF > $FILE.sha256sum
20a5e3d2907d054bf143421da8b068f31772a58e0caa348bb050770edddfe6f1  MR_LINUX_DRIVER_7.5-07.705.02.00-1.tgz
EOF
sha256sum -c $FILE.sha256sum
rm $FILE.sha256sum

mkdir -p $DIR
tar -C $DIR -xvf $FILE
rm $FILE

tar --strip-components=1 -xvf $DIR/megaraid_sas-07.705.02.00-src.tar.gz
rm -r $DIR

VERSION=07.705.02.00
sed -i -e "s/^\(PACKAGE_VERSION=\).*/\1$VERSION/g" dkms.conf
